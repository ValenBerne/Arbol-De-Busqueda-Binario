#include "abb.c"
#include "abb_minipruebas.c"
#include "pruebas.c"

int main(){
    abb_minipruebas();
    printf("\n\n");
    printf("------------------------------------------------------------------");
    printf("\n\n\n");
    printf("Mis Pruebas");
    printf("\n\n");
    pruebas_mias();
}